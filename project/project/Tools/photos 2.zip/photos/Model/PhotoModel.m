//
//  PhotoModel.m
//  NIM
//
//  Created by apple on 2017/10/14.
//  Copyright © 2017年 Netease. All rights reserved.
//

#import "PhotoModel.h"

@implementation PhotoModel

@end
