//
//  PhotoModel.h
//  NIM
//
//  Created by apple on 2017/10/14.
//  Copyright © 2017年 Netease. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PhotoModel : NSObject

@property (nonatomic , strong) UIImage *    image;
@property (nonatomic , strong) NSString*    isSelect;

@end
