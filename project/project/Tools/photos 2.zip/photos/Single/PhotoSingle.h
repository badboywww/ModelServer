//
//  PhotoSingle.h
//  NIM
//
//  Created by apple on 2017/10/13.
//  Copyright © 2017年 Netease. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PhotoSingle : NSObject

@end
