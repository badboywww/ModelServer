//
//  PhotoViewController.h
//  project
//
//  Created by Bad on 2018/10/10.
//  Copyright © 2018 Bad. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>

NS_ASSUME_NONNULL_BEGIN

@interface PhotoViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
